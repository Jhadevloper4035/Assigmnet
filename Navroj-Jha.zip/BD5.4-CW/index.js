const express = require("express");
let { sequelize } = require("./lib/index.js");
let { track } = require("./models/track_model.js");
let { user } = require("./models/user_model.js");

const app = express();
const port = 3000;
app.use(express.json());

const userData = [
  {
    username: "Navroj jha ",
    email: "navrojjha21@gmail.com",
    password: "8448520798",
  },
];

app.get("/seed_database", async (req, res) => {
  try {
    await sequelize.sync({ force: true });
    await user.bulkCreate(userData);
    return res.status(200).json({ message: "database is ready to use " });
  } catch (error) {
    return res
      .status(200)
      .json({ message: "error in seeding database", error: error.message });
  }
});

async function addNewUser(newUser) {
  let respo = await user.create(newUser);
  return { respo };
}

app.post("/users/new", async (req, res) => {
  try {
    let newUser = req.body.newUser;
    let result = await addNewUser(newUser);
    return res.status(200).json(result);
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
});

async function updateUserById(id, newUserData) {
  let userDetails = await user.findOne({ where: { id } });
  if (!userDetails) return {};
  userDetails.set(newUserData);
  let updatedUser = await userDetails.save();
  return { message: "user updated successfully ", updatedUser };
}

app.post("/users/update/:id", async (req, res) => {
  try {
    let newUserData = req.body;
    let id = parseInt(req.params.id);
    let result = await updateUserById(id, newUserData);
    return res.status(200).json(result);
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
