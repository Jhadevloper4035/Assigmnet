let { DataTypes, sequelize } = require("../lib/index.js");
let { student } = require("./student_model.js");
let { course } = require("./course_model.js");

let studentcourse = sequelize.define("studentcourse", {
  studentId: {
    type: DataTypes.INTEGER,
    references: {
      model: student,
      key: "id",
    },
  },
  courseId: {
    type: DataTypes.INTEGER,
    references: {
      model: course,
      key: "id",
    },
  },
});

student.belongsToMany(course, { through: studentcourse });
course.belongsToMany(student, { through: studentcourse });
module.exports = { studentcourse };
