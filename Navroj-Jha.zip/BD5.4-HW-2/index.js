const express = require("express");
let { sequelize } = require("./lib/index.js");
let { student } = require("./models/student_model.js");
let { course } = require("./models/course_model.js");

const app = express();
const port = 3000;
app.use(express.json());

const courseData = [
  { title: "Math 101", description: "Basic Mathematics" },
  { title: "History 201", description: "World History" },
  { title: "Science 301", description: "Basic Sciences" },
];

app.get("/seed_database", async (req, res) => {
  try {
    await sequelize.sync({ force: true });
    await course.bulkCreate(courseData);
    return res.status(200).json({ message: "database is ready to use " });
  } catch (error) {
    return res
      .status(200)
      .json({ message: "error in seeding database", error: error.message });
  }
});

async function addNewStudent(newStudent) {
  let createdStudent = await student.create(newStudent);
  return { createdStudent };
}

app.post("/students/new", async (req, res) => {
  try {
    let newStudent = req.body.newStudent;
    let result = await addNewStudent(newStudent);
    return res.status(200).json(result);
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
});

async function updateStudentById(id, newStudentData) {
  let studentDetails = await student.findOne({ where: { id } });
  if (!studentDetails) return {};
  studentDetails.set(newStudentData);
  let updatedStudent = await studentDetails.save();
  return { message: "student updated successfully", updatedStudent };
}

app.post("/students/update/:id", async (req, res) => {
  try {
    let newStudentData = req.body;
    let id = parseInt(req.params.id);
    let result = await updateStudentById(id, newStudentData);
    return res.status(200).json(result);
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
