let { DataTypes, sequelize } = require("../lib/index.js");

let books = sequelize.define("books", {
  title: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false,
  },
  genre: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  bookauthors: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
});

module.exports = { books };
