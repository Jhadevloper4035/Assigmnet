let { DataTypes, sequelize } = require("../lib/index.js");
let { authors } = require("./authors_model.js");
let { books } = require("./books_model.js");

let bookauthors = sequelize.define("bookauthors", {
  authorId: {
    type: DataTypes.INTEGER,
    references: {
      model: authors,
      key: "id",
    },
  },
  books: {
    type: DataTypes.INTEGER,
    references: {
      model: books,
      key: "id",
    },
  },
});

authors.belongsToMany(books, { through: bookauthors });
books.belongsToMany(authors, { through: bookauthors });
module.exports = { bookauthors };
