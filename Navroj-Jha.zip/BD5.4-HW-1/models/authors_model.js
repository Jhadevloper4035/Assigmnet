let { DataTypes, sequelize } = require("../lib/index.js");

let authors = sequelize.define("authors", {
  name: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false,
  },
  birthyear: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
});

module.exports = { authors };
