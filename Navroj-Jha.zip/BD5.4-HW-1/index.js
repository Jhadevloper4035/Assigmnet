const express = require("express");
let { sequelize } = require("./lib/index.js");
let { books } = require("./models/books_model.js");
let { authors } = require("./models/authors_model.js");

const app = express();
const port = 3000;
app.use(express.json());

const booksData = [
  {
    title: "Harry Potter and the Philosophers Stone",
    genre: "Fantasy",
    publicationYear: 1997,
  },
  { title: "A Game of Thrones", genre: "Fantasy", publicationYear: 1996 },
  { title: "The Hobbit", genre: "Fantasy", publicationYear: 1937 },
];

app.get("/seed_database", async (req, res) => {
  try {
    await sequelize.sync({ force: true });
    await books.bulkCreate(booksData);
    return res.status(200).json({ message: "database is ready to use " });
  } catch (error) {
    return res
      .status(200)
      .json({ message: "error in seeding database", error: error.message });
  }
});

async function addNewAuthor(newAuthor) {
  let createdAuthor = await authors.create(newAuthor);
  return { createdAuthor };
}

app.post("/authors/new", async (req, res) => {
  try {
    let newAuthor = req.body.newAuthor;
    let result = await addNewAuthor(newAuthor);
    return res.status(200).json(result);
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
});

async function updateAuthorById(id, newAuthorData) {
  let authorDetails = await authors.findOne({ where: { id } });
  if (!authorDetails) return {};
  authorDetails.set(newAuthorData);
  let updatedAuthor = await authorDetails.save();
  return { message: "author updated successfully", updatedAuthor };
}

app.post("/authors/update/:id", async (req, res) => {
  try {
    let newAuthorData = req.body;
    let id = parseInt(req.params.id);
    let result = await updateAuthorById(id, newAuthorData);
    return res.status(200).json(result);
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
