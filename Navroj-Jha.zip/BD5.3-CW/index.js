const express = require("express");
let { sequelize } = require("./lib/index.js");
let { track } = require("./models/track_model.js");
const { where } = require("sequelize");

const app = express();
const port = 3000;
app.use(express.json());

const trackData = [
  {
    name: "Raabta",
    genre: "Romantic",
    release_year: 2012,
    artist: "Arijit Singh",
    album: "Agent Vinod",
    duration: 4,
  },
  {
    name: "Naina Da Kya Kasoor",
    genre: "Pop",
    release_year: 2018,
    artist: "Amit Trivedi",
    album: "Andhadhun",
    duration: 3,
  },
  {
    name: "Ghoomar",
    genre: "Traditional",
    release_year: 2018,
    artist: "Shreya Ghoshal",
    album: "Padmaavat",
    duration: 3,
  },
  {
    name: "Bekhayali",
    genre: "Rock",
    release_year: 2019,
    artist: "Sachet Tandon",
    album: "Kabir Singh",
    duration: 6,
  },
  {
    name: "Hawa Banke",
    genre: "Romantic",
    release_year: 2019,
    artist: "Darshan Raval",
    album: "Hawa Banke (Single)",
    duration: 3,
  },
  {
    name: "Ghungroo",
    genre: "Dance",
    release_year: 2019,
    artist: "Arijit Singh",
    album: "War",
    duration: 5,
  },
  {
    name: "Makhna",
    genre: "Hip-Hop",
    release_year: 2019,
    artist: "Tanishk Bagchi",
    album: "Drive",
    duration: 3,
  },
  {
    name: "Tera Ban Jaunga",
    genre: "Romantic",
    release_year: 2019,
    artist: "Tulsi Kumar",
    album: "Kabir Singh",
    duration: 3,
  },
  {
    name: "First Class",
    genre: "Dance",
    release_year: 2019,
    artist: "Arijit Singh",
    album: "Kalank",
    duration: 4,
  },
  {
    name: "Kalank Title Track",
    genre: "Romantic",
    release_year: 2019,
    artist: "Arijit Singh",
    album: "Kalank",
    duration: 5,
  },
];

app.get("/seed_database", async (req, res) => {
  try {
    await sequelize.sync({ force: true });
    await track.bulkCreate(trackData);
    return res.status(200).json({ message: "database is ready to use " });
  } catch (error) {
    return res
      .status(200)
      .json({ message: "error in seeding database", error: error.message });
  }
});

async function fetchAllTracks() {
  let tracks = await track.findAll();
  return { tracks };
}

async function addNewTrack(newTrack) {
  let tracks = await track.create(newTrack);
  return { tracks };
}

async function updateTrackById(newTrackData, id) {
  const trackDetails = await track.findOne({ where: { id } });
  if (!trackDetails) return {};
  trackDetails.set(newTrackData);
  let tracks = await trackDetails.save();
  return { message: "Track updated successfully", tracks };
}

async function deleteTrackById(id) {
  let destroyedTrack = await track.destroy({ where: { id } });
  if (destroyedTrack === 0) return {};
  return { message: "Track deleted successfully" };
}

app.get("/track", async (req, res) => {
  try {
    let result = await fetchAllTracks();

    if (result.tracks.length === 0)
      return res.status(404).json({ message: "no track found" });
    return res.status(200).json(result);
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
});

app.post("/track/new", async (req, res) => {
  try {
    let newTrack = req.body.newTrack;
    let result = await addNewTrack(newTrack);
    return res.status(200).json(result);
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
});

app.post("/track/update/:id", async (req, res) => {
  try {
    let newTrackData = req.body;
    let id = parseInt(req.params.id);
    let result = await updateTrackById(newTrackData, id);
    return res.status(200).json(result);
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
});

app.post("/track/delete", async (req, res) => {
  try {
    let id = parseInt(req.body.id);
    let result = await deleteTrackById(id);
    return res.status(200).json(result);
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
