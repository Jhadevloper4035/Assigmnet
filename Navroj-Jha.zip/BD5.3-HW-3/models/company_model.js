const { sequelize, DataTypes } = require("../lib/index.js");

const companies = sequelize.define("companies", {
  name: DataTypes.TEXT,
  industry: DataTypes.TEXT,
  foundedYear: DataTypes.INTEGER,
  headquarters: DataTypes.TEXT,
  revenue: DataTypes.INTEGER,
});

module.exports = { companies };
