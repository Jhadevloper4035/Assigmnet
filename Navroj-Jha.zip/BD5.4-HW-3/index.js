const express = require("express");
let { sequelize } = require("./lib/index.js");
let { chef } = require("./models/chef_model.js");
let { dishe } = require("./models/dishe_model.js");

const app = express();
const port = 3000;
app.use(express.json());

let disheData = [
  {
    name: "Margherita Pizza",
    cuisine: "Italian",
    preparationTime: 20,
  },
  {
    name: "Sushi",
    cuisine: "Japanese",
    preparationTime: 50,
  },
  {
    name: "Poutine",
    cuisine: "Canadian",
    preparationTime: 30,
  },
];

app.get("/seed_database", async (req, res) => {
  try {
    await sequelize.sync({ force: true });
    await dishe.bulkCreate(disheData);
    return res.status(200).json({ message: "database is ready to use " });
  } catch (error) {
    return res
      .status(200)
      .json({ message: "error in seeding database", error: error.message });
  }
});

async function addNewChefto(newChef) {
  let createdChef = await chef.create(newChef);
  return { createdChef };
}

app.post("/chefs/new", async (req, res) => {
  try {
    let newChef = req.body.newChef;
    let result = await addNewChefto(newChef);
    return res.status(200).json(result);
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
});

async function updateChefById(id, newChefData) {
  let chefDetails = await chef.findOne({ where: { id } });
  if (!chefDetails) return {};
  chefDetails.set(newChefData);
  let updatedChef = await chefDetails.save();
  return { message: "chef updated successfully", updatedChef };
}

app.post("/chefs/update/:id", async (req, res) => {
  try {
    let newChefData = req.body;
    let id = parseInt(req.params.id);
    let result = await updateChefById(id, newChefData);
    return res.status(200).json(result);
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
