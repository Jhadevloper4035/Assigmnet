let { DataTypes, sequelize } = require("../lib/index.js");

let dishe = sequelize.define("dishe", {
  name: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  cuisine: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  preparationTime: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
});

module.exports = { dishe };
