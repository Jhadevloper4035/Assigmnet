let { DataTypes, sequelize } = require("../lib/index.js");
let { chef } = require("./chef_model.js");
let { dishe } = require("./dishe_model.js");

let chefdish = sequelize.define("chefdish", {
  chefId: {
    type: DataTypes.INTEGER,
    references: {
      model: chef,
      key: "id",
    },
  },
  dishId: {
    type: DataTypes.INTEGER,
    references: {
      model: dishe,
      key: "id",
    },
  },
});

chef.belongsToMany(dishe, { through: chefdish });
dishe.belongsToMany(chef, { through: chefdish });

module.exports = { chefdish };
